package assignment;

import java.util.Scanner;

public class CasualStaff extends User{

	public CasualStaff(String employeeID, String name, int phone, String email) {
		super(employeeID, name, phone, email);
	}
	
	
	

}
