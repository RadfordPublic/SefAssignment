package assignment;

public class Coordinator {

}
