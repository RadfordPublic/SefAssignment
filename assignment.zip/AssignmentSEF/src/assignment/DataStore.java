package assignment;

public class DataStore {
	

}
