package assignment;

public class Course {

}
