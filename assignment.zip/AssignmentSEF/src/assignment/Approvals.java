package assignment;

public class Approvals {

}
