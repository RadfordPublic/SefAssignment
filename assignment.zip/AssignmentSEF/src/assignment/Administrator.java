package assignment;

public class Administrator {

}
